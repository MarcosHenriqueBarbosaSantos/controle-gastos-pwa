// Servidor de avisos do Meus Gastos (Supabase Edge Function).
//   GET                         → { chavePublica }: chave que o app usa para ligar as notificações no aparelho
//   GET ?autoteste=1            → confere, no próprio servidor, as regras e a criptografia com respostas conhecidas
//   POST + x-avisos-segredo     → rotina diária (chamada pelo agendamento do banco): avisa quem tem conta para vencer
//                                 ou chegou perto, passou ou passou muito do limite de gastos do mês, e manda os recados
//                                 da meta do dinheiro guardado (lembrete de guardar e parabéns por ter guardado)
//   POST + x-avisos-segredo     → { rotina: "noite" } (agendamento das 20h): no domingo manda o resumo da semana; nos outros dias,
//                                 a notificação de lembrete para quem pediu e não anotou nada no dia
//   POST + login do usuário     → { teste: true }: manda um aviso de teste só para quem pediu
//                                 { teste: "semana" } ou { teste: "noite" }: manda agora o resumo da semana ou o lembrete, para ver como fica
// Conta de casal: quem divide as contas com outra pessoa é avisado sobre as contas, o limite e as metas dos dois juntos.
// As dependências chegam por parâmetro para o mesmo código rodar nos testes (Node) e no Supabase (Deno).
import { pendenciasParaAviso, calcMes, usoDoTeto, mKey, faturasDoMes, proximosVencimentos, projetaDiaADia, ocorrencias, diasEntre,
  lembreteDaMeta, parabensDaMeta, andamentoDaMeta, sugestaoDaMeta, diaDaSemana, resumoDaSemana, lembreteDoDia, comumDoCasal } from "./regras.js";
import { enviaPush, gerarChaves, cifra, b64u, deB64u, cabecalhoVapid } from "./webpush.js";
import { montaAviso, avisoDeTeste, avisoDoLimite, avisoDaMeta, avisoDaSemana, avisoDaNoite } from "./mensagem.js";

const CORS = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type" };
const json = (obj, status = 200) => new Response(JSON.stringify(obj), { status, headers: { ...CORS, "Content-Type": "application/json" } });
const APP_PADRAO = "https://meugastos.com.br/";

/**
 * Autoteste: roda no servidor de verdade e compara com respostas conhecidas. Não usa o banco nem envia nada.
 * Serve para confirmar, depois de publicar, que o servidor está com o código certo.
 */
export async function autoteste() {
  const falhas = [], confere = (nome, obtido, esperado) => { if (JSON.stringify(obtido) !== JSON.stringify(esperado)) falhas.push({ nome, obtido, esperado }); };
  const fx = (id, descricao, dia, valor, forma = "Boleto", extra = {}) => ({ id, tipo: "Despesa", descricao, categoria: "Moradia", dia, valor, forma, desde: "2026-08-01", ate: null, ...extra });
  const st = { pagos: [{ fixo_id: "p", mes: "2026-10-01" }], cartoes: [{ id: "k", nome: "Roxo", fechamento: 3, vencimento: 5 }],
    lancamentos: [{ id: "l", data: "2026-09-10", descricao: "Geladeira", tipo: "Despesa", categoria: "Outros", forma: "Cartão de crédito", cartao_id: "k", parcelas: 3, valor: 900 }],
    fixos: [fx("a", "Aluguel", 1, 1000), fx("i", "Internet", 6, 100), fx("f", "Faculdade", 20, 349), fx("p", "Pago", 2, 50), fx("s", "Streaming", 15, 40, "Cartão de crédito", { cartao_id: "k", desde: "2026-09-01" }),
      fx("u", "Uber", 1, 30, "Pix", { repete: "semanal", dia_semana: 0, desde: "2026-10-01" })],
    faturas: [{ id: "v", cartao: "Velha", vencimento: "2026-08-10", valor: 80, status: "Aberta" }, { id: "n", cartao: "Loja", vencimento: "2026-10-03", valor: 120, status: "Aberta" }] };
  const p = pendenciasParaAviso(st, "2026-10-03");
  confere("pendências", p.itens.map((x) => [x.titulo, x.dias, x.valor]), [["Aluguel", -2, 1000], ["Fatura Loja", 0, 120], ["Uber", 1, 30], ["Fatura Roxo", 2, 340], ["Internet", 3, 100]]);
  confere("totais", [p.atrasadas, p.hoje, p.total], [1, 1, 1590]);
  const a = montaAviso(p, "https://app/");
  confere("título", a.titulo, "1 conta atrasada e 4 para vencer");
  confere("valor em reais", a.assunto.replace(/\s/g, " "), "Meus Gastos: 1 conta atrasada e 4 para vencer (R$ 1.590,00)");
  confere("data de Brasília", new Intl.DateTimeFormat("en-CA", { timeZone: "America/Sao_Paulo" }).format(new Date("2026-10-04T02:30:00Z")), "2026-10-03");
  // Criptografia: exemplo oficial da RFC 8291 (apêndice A).
  const asPub = deB64u("BP4z9KsN6nGRTbVYI_c7VJSPQTBtkgcy27mlmlMoZIIgDll6e3vCYLocInmYWAmS6TlzAC8wEqKK6PBru3jl7A8");
  const jwk = { kty: "EC", crv: "P-256", d: "yfWPiYE-n46HLnH0KqZOF1fJJU3MYrct3AELtAQ-oRw", x: b64u(asPub.slice(1, 33)), y: b64u(asPub.slice(33)) };
  const efemera = { privateKey: await crypto.subtle.importKey("jwk", jwk, { name: "ECDH", namedCurve: "P-256" }, true, ["deriveBits"]),
    publicKey: await crypto.subtle.importKey("raw", asPub, { name: "ECDH", namedCurve: "P-256" }, true, []) };
  const cif = await cifra("When I grow up, I want to be a watermelon", "BCVxsr7N_eNgVRqvHtD0zTZsEc6-VV-JvLexhqUzORcxaOzi6-AYWXvTBHm4bjyPjs7Vd8pZGH6SRpkNtoIAiw4", "BTBZMqHH6r4Tts7J_aSIgg",
    { efemera, salt: deB64u("DGv6ra1nlYgDCS1FRnbzlw") });
  confere("criptografia", b64u(cif), "DGv6ra1nlYgDCS1FRnbzlwAAEABBBP4z9KsN6nGRTbVYI_c7VJSPQTBtkgcy27mlmlMoZIIgDll6e3vCYLocInmYWAmS6TlzAC8wEqKK6PBru3jl7A_yl95bQpu6cVPTpK4Mqgkf1CXztLVBSt2Ks3oZwbuwXPXLWyouBWLVWGNWQexSgSxsj_Qulcy4a-fN");
  const k = await gerarChaves();
  confere("chave gerada", deB64u(k.publica).length, 65);
  // Limite do mês: custo de outubro = fixos fora do cartão (1.000 + 100 + 349 + 50 + 4 domingos × 30 do Uber) + faturas (120 + 340) = 2.079.
  const u = usoDoTeto(calcMes(st, "2026-10", "2026-10-03"), 2000);
  confere("limite do mês", [u.gasto, u.pct, u.nivel, u.resta], [2079, 104, 100, -79]);
  confere("aviso do limite", avisoDoLimite(u, "2026-10-03").titulo, "Você passou do limite de outubro");
  // Meta do dinheiro guardado: 900 guardados em três meses, salário no dia 5. No dia do salário, lembra de separar os 300 do ritmo.
  const res = (data, valor) => ({ id: data, data, descricao: "", tipo: "Reserva", categoria: "Reserva", forma: "", valor });
  const sm = { pagos: [], cartoes: [], faturas: [], lancamentos: [res("2026-07-28", 300), res("2026-08-28", 300), res("2026-09-28", 300), res("2026-10-04", 600)],
    fixos: [{ id: "r", tipo: "Receita", descricao: "Salário", categoria: "Salário", dia: 5, valor: 3900, forma: "", desde: "2026-01-01", ate: null }] };
  const par = parabensDaMeta(sm, { Reserva: { valor: 3000 } }, "2026-10-05");
  confere("parabéns da meta", [par.valor, par.guardado, par.pct, par.marco], [600, 1500, 50, 50]);
  confere("texto dos parabéns", avisoDaMeta({ tipo: "parabens", ...par }, "2026-10-05").titulo, "Você chegou a 50% da meta Reserva");
  const lem = lembreteDaMeta({ ...sm, lancamentos: sm.lancamentos.slice(0, 3) }, { Reserva: { valor: 3000 } }, "2026-10-05");
  confere("lembrete da meta", [lem.quando, lem.valor, lem.completo, lem.meta.previsao], ["entrou", 300, true, "2027-04"]);
  // Resumo da semana (segunda 28/09 a domingo 04/10) e lembrete do fim do dia.
  const g = (data, valor, categoria, descricao = "Gasto") => ({ id: data + valor, data, descricao, tipo: "Despesa", categoria, forma: "Pix", valor });
  const ss = { pagos: [], cartoes: [], faturas: [], fixos: [fx("i", "Internet", 6, 100)],
    lancamentos: [g("2026-09-22", 80, "Mercado"), g("2026-09-28", 50, "Mercado"), g("2026-10-01", 120.5, "Mercado", "Compra do mês"), g("2026-10-03", 30, "Transporte")] };
  const rs = resumoDaSemana(ss, "2026-10-04");
  confere("resumo da semana", [rs.de, rs.total, rs.n, rs.dif, rs.cats.map((x) => [x.cat, x.valor]), rs.anotados, rs.proximas.itens.map((x) => x.titulo), rs.proximas.total],
    ["2026-09-28", 200.5, 3, 120.5, [["Mercado", 170.5], ["Transporte", 30]], 3, ["Internet"], 100]);
  confere("texto do resumo", avisoDaSemana(rs, "https://app/").titulo.replace(/\s/g, " "), "Sua semana: R$ 200,50 em 3 gastos");
  confere("lembrete do dia", [lembreteDoDia(ss, "2026-10-04"), lembreteDoDia(ss, "2026-10-03"), lembreteDoDia(ss, "2026-10-12")], [{ seq: 1, parado: 1 }, null, null]);
  return { ok: falhas.length === 0, conferidos: 15, falhas, assinatura: assinatura() };
}

/**
 * Impressão digital do código que está rodando: um número calculado a partir do texto das funções principais.
 * Depois de publicar, o número do servidor tem de ser igual ao calculado aqui no projeto (ver tests/avisos.test.mjs).
 */
export function assinatura() {
  const texto = [criaHandler, autoteste, montaAviso, avisoDeTeste, avisoDoLimite, avisoDaMeta, pendenciasParaAviso, calcMes, usoDoTeto, faturasDoMes, proximosVencimentos, projetaDiaADia, ocorrencias,
    lembreteDaMeta, parabensDaMeta, andamentoDaMeta, sugestaoDaMeta, resumoDaSemana, lembreteDoDia, avisoDaSemana, avisoDaNoite,
    enviaPush, gerarChaves, cifra, cabecalhoVapid].map(String).join("\n");
  let h = 5381; for (let i = 0; i < texto.length; i++) h = ((h << 5) + h + texto.charCodeAt(i)) | 0;
  return `${texto.length}-${(h >>> 0).toString(36)}`;
}

export function criaHandler({ createClient, env, fetchFn = fetch, agora = () => new Date() }) {
  const admin = () => createClient(env("SUPABASE_URL"), env("SUPABASE_SERVICE_ROLE_KEY"), { auth: { persistSession: false, autoRefreshToken: false } });
  const urlApp = () => env("AVISOS_URL_APP") || APP_PADRAO;
  // "Hoje" no horário de Brasília, que é o dos vencimentos.
  const diaDe = (d) => new Intl.DateTimeFormat("en-CA", { timeZone: "America/Sao_Paulo" }).format(d);
  const hoje = () => diaDe(agora());

  /** Chaves das notificações: criadas na primeira vez e guardadas numa tabela que só o servidor lê. */
  async function chaves(db) {
    const ler = async () => (await db.from("avisos_chaves").select("publica, privada").eq("id", 1).maybeSingle()).data;
    let k = await ler();
    if (!k) { const novas = await gerarChaves(); await db.from("avisos_chaves").upsert({ id: 1, ...novas }, { onConflict: "id", ignoreDuplicates: true }); k = await ler(); }
    if (!k) throw new Error("Não foi possível criar as chaves de notificação (a tabela avisos_chaves existe?).");
    return k;
  }

  /** Todas as linhas de uma tabela de um usuário (o banco devolve no máximo 1.000 por vez). */
  async function linhas(db, tabela, uid, colunas = "*") {
    const out = [];
    for (let de = 0; ; de += 1000) {
      const { data, error } = await db.from(tabela).select(colunas).eq("user_id", uid).range(de, de + 999);
      if (error) { if (tabela === "cartoes") return []; throw new Error(`${tabela}: ${error.message}`); }
      out.push(...data);
      if (data.length < 1000) return out;
    }
  }
  /** Com quem a pessoa divide as contas (supabase/casal.sql) e o que é dos dois. Sem conta de casal, ou com o banco sem essa parte: null. */
  async function casalDe(db, uid) {
    for (const papel of ["dono", "parceiro"]) {
      const { data, error } = await db.from("casais").select("dono, parceiro, dados").eq("status", "ativo").eq(papel, uid).maybeSingle();
      if (error) return null;
      if (data?.parceiro) return { outro: data.dono === uid ? data.parceiro : data.dono, dados: data.dados || {} };
    }
    return null;
  }
  /** Os dados da pessoa; em conta de casal, os dos dois juntos, como ela vê no app. */
  async function estado(db, uid, casal = null) {
    const de = async (id) => Promise.all([linhas(db, "lancamentos", id), linhas(db, "fixos", id), linhas(db, "fixos_pagos", id, "fixo_id, mes"), linhas(db, "faturas", id), linhas(db, "cartoes", id)]);
    const partes = await Promise.all((casal ? [uid, casal.outro] : [uid]).map(de)), junta = (i) => partes.flatMap((p) => p[i]);
    const num = (r) => ({ ...r, valor: Number(r.valor) });
    return { lancamentos: junta(0).map(num), fixos: junta(1).map(num), pagos: junta(2), faturas: junta(3).map(num), cartoes: junta(4) };
  }
  /** As preferências da pessoa; em conta de casal, o limite, as metas e o resto que é dos dois vêm da conta de casal. */
  async function prefsDe(db, uid, casal = null) {
    const { data: pref } = await db.from("preferencias").select("dados").eq("user_id", uid).maybeSingle();
    return casal ? { ...(pref?.dados || {}), ...comumDoCasal(casal.dados) } : pref?.dados || {};
  }

  /**
   * Envia o e-mail pelo serviço que estiver configurado nos segredos da função:
   * RESEND_API_KEY (Resend) ou BREVO_API_KEY (Brevo), mais AVISOS_REMETENTE (o endereço que envia).
   */
  async function mandaEmail(para, aviso) {
    const resend = env("RESEND_API_KEY"), brevo = env("BREVO_API_KEY"), remetente = env("AVISOS_REMETENTE");
    if ((!resend && !brevo) || !remetente) return "não configurado";
    const r = resend
      ? await fetchFn("https://api.resend.com/emails", { method: "POST",
          headers: { Authorization: `Bearer ${resend}`, "Content-Type": "application/json" },
          body: JSON.stringify({ from: `Meus Gastos <${remetente}>`, to: [para], subject: aviso.assunto, html: aviso.html, text: aviso.texto }) })
      : await fetchFn("https://api.brevo.com/v3/smtp/email", { method: "POST",
          headers: { "api-key": brevo, "Content-Type": "application/json", Accept: "application/json" },
          body: JSON.stringify({ sender: { name: "Meus Gastos", email: remetente }, to: [{ email: para }], subject: aviso.assunto, htmlContent: aviso.html, textContent: aviso.texto }) });
    if (r.ok) return "enviado";
    return `erro ${r.status}: ${(await r.text().catch(() => "")).slice(0, 200)}`;
  }

  /** Notifica todos os aparelhos do usuário. Inscrições que não existem mais são apagadas. */
  async function mandaPush(db, uid, aviso, k) {
    const { data: subs } = await db.from("avisos_push").select("id, endpoint, p256dh, auth").eq("user_id", uid);
    let ok = 0;
    for (const s of subs || []) {
      try {
        const st = await enviaPush(s, { titulo: aviso.titulo, corpo: aviso.corpo, url: aviso.url, tag: aviso.tag }, k, `mailto:${env("AVISOS_REMETENTE") || "avisos@meusgastos.app"}`, fetchFn);
        if (st >= 200 && st < 300) ok++;
        else if (st === 404 || st === 410) await db.from("avisos_push").delete().eq("id", s.id);
        else console.warn("push", st, s.endpoint.slice(0, 60));
      } catch (e) { console.warn("push falhou:", e?.message); }
    }
    return { aparelhos: (subs || []).length, entregues: ok };
  }

  /**
   * Limite do mês: devolve o uso quando a pessoa chegou a um nível (80%, passou, passou muito) que ainda não foi avisado neste mês.
   * O nível já avisado fica anotado em avisos_enviados (campo canais), então cada nível gera um aviso só.
   */
  async function limiteParaAvisar(db, uid, st, dados, dia) {
    if (!(Number(dados?.teto) > 0) || dados?.avisos?.limite === false) return null;
    const u = usoDoTeto(calcMes(st, mKey(dia), dia), dados.teto);
    if (!u || !u.nivel) return null;
    const { data } = await db.from("avisos_enviados").select("dia, canais").eq("user_id", uid);
    const jaAvisado = Math.max(0, ...(data || []).filter((r) => String(r.dia).slice(0, 7) === mKey(dia)).map((r) => Number((String(r.canais || "").match(/limite: (\d+)/) || [])[1]) || 0));
    return u.nivel > jaAvisado ? u : null;
  }

  /**
   * Recado da meta do dinheiro guardado. São poucos de propósito:
   * - parabéns no dia seguinte a guardar: no máximo um por semana, a não ser que a pessoa tenha cruzado um marco (25, 50, 75 ou 100%);
   * - lembrete quando o dinheiro entra e quando deve sobrar no fim do mês: cada um uma vez por mês, e nunca em mês apertado.
   * O que já foi enviado fica anotado em avisos_enviados (campo canais, "meta: ...").
   */
  async function metaParaAvisar(db, uid, st, dados, dia) {
    if (dados?.avisos?.meta === false || !dados?.metas || !Object.keys(dados.metas).length) return null;
    const { data } = await db.from("avisos_enviados").select("dia, canais").eq("user_id", uid);
    const ja = (data || []).map((r) => ({ dia: String(r.dia).slice(0, 10), tag: (String(r.canais || "").match(/meta: (\w+)/) || [])[1] })).filter((x) => x.tag);
    const par = parabensDaMeta(st, dados.metas, dia);
    if (par && (par.marco || !ja.some((x) => x.tag === "parabens" && diasEntre(x.dia, dia) < 7))) return { tipo: "parabens", ...par };
    const lem = lembreteDaMeta(st, dados.metas, dia);
    if (lem && !ja.some((x) => x.tag === lem.quando && x.dia.slice(0, 7) === mKey(dia))) return { tipo: "lembrete", ...lem };
    return null;
  }

  async function avisaUsuario(db, user, k, { teste = false } = {}) {
    const dia = hoje(), casal = await casalDe(db, user.id), st = await estado(db, user.id, casal), p = pendenciasParaAviso(st, dia);
    const dados = await prefsDe(db, user.id, casal);
    const lim = await limiteParaAvisar(db, user.id, st, dados, dia), rec = await metaParaAvisar(db, user.id, st, dados, dia);
    if (!p.itens.length && !lim && !rec && !teste) return null;
    const aviso = p.itens.length || lim || rec ? montaAviso(p, urlApp(), lim && avisoDoLimite(lim, dia), rec && avisoDaMeta(rec, dia)) : avisoDeTeste(urlApp());
    const querEmail = dados.avisos?.email !== false;
    const email = user.email && querEmail ? await mandaEmail(user.email, aviso) : "desligado";
    const push = await mandaPush(db, user.id, aviso, k);
    return { pendencias: p.itens.length, limite: lim ? lim.nivel : 0, meta: rec ? (rec.tipo === "parabens" ? "parabens" : rec.quando) : "", email, push };
  }

  /**
   * Anota o que foi enviado no dia. A linha é uma por pessoa por dia: a rotina da manhã e a da noite escrevem na mesma,
   * cada uma com a sua marca ("email: ..." de manhã, "noite: ..." à noite), e é por essa marca que nenhuma repete o envio.
   */
  async function anota(db, uid, dia, trecho, naFrente = false) {
    const { data: ja } = await db.from("avisos_enviados").select("canais").eq("user_id", uid).eq("dia", dia).maybeSingle();
    if (!ja) return db.from("avisos_enviados").insert({ user_id: uid, dia, canais: trecho.slice(0, 300) });
    const canais = (naFrente ? `${trecho}; ${ja.canais || ""}` : `${ja.canais || ""}; ${trecho}`).slice(0, 400);
    return db.from("avisos_enviados").update({ canais }).eq("user_id", uid).eq("dia", dia);
  }
  const todos = async (db, cada) => {
    for (let page = 1; page <= 500; page++) {
      const { data, error } = await db.auth.admin.listUsers({ page, perPage: 200 });
      if (error) throw new Error(error.message);
      for (const user of data.users) await cada(user);
      if (data.users.length < 200) break;
    }
  };

  /**
   * O que a pessoa recebe à noite. No domingo, o resumo da semana (e-mail e notificação), para quem anotou algo nas últimas duas semanas.
   * Nos outros dias, ou para quem desligou o resumo: a notificação de lembrete, só para quem pediu e não anotou nada hoje.
   * `so` força um dos dois, para o botão "ver como fica" do app.
   */
  async function noiteDoUsuario(db, user, k, dia, so = "") {
    const casal = await casalDe(db, user.id), dados = await prefsDe(db, user.id, casal), semGasto = Array.isArray(dados.semGasto) ? dados.semGasto : [];
    const querSemana = so === "semana" || (!so && diaDaSemana(dia) === 0 && dados.avisos?.semana !== false);
    const querNoite = so === "noite" || (!so && dados.avisos?.noite === true);
    if (!querSemana && !querNoite) return null;
    const st = await estado(db, user.id, casal);
    if (querSemana && (so || [...st.lancamentos.map((x) => x.data), ...semGasto].some((d) => d <= dia && diasEntre(d, dia) < 14))) {
      const u = Number(dados.teto) > 0 ? usoDoTeto(calcMes(st, mKey(dia), dia), dados.teto) : null;
      const aviso = avisoDaSemana(resumoDaSemana(st, dia, semGasto), urlApp(), u);
      const email = user.email && dados.avisos?.email !== false ? await mandaEmail(user.email, aviso) : "desligado";
      return { tipo: "semana", email, push: await mandaPush(db, user.id, aviso, k) };
    }
    if (!querNoite) return null;
    const anotouHoje = st.lancamentos.some((x) => x.created_at && diaDe(new Date(x.created_at)) === dia);
    const l = lembreteDoDia(st, dia, { semGasto, anotouHoje, desde: user.created_at ? diaDe(new Date(user.created_at)) : "" }) || (so ? { seq: 0, parado: 0 } : null);
    if (!l) return null;
    const push = await mandaPush(db, user.id, avisoDaNoite(l, urlApp()), k);
    return push.aparelhos || so ? { tipo: "lembrete", email: "", push } : null;
  }

  async function rotinaDaNoite(db) {
    const k = await chaves(db), dia = hoje(), res = { dia, rotina: "noite", usuarios: 0, resumos: 0, lembretes: 0, emails: 0, notificacoes: 0, erros: [] };
    await todos(db, async (user) => {
      res.usuarios++;
      try {
        const { data: ja } = await db.from("avisos_enviados").select("canais").eq("user_id", user.id).eq("dia", dia).maybeSingle();
        if (/noite: /.test(ja?.canais || "")) return;   // uma vez por noite, mesmo que a rotina rode duas vezes
        const r = await noiteDoUsuario(db, user, k, dia);
        if (!r) return;
        if (r.tipo === "semana") res.resumos++; else res.lembretes++;
        if (r.email === "enviado") res.emails++; res.notificacoes += r.push.entregues;
        if (/^erro/.test(r.email)) res.erros.push(`e-mail: ${r.email}`);
        await anota(db, user.id, dia, `noite: ${r.tipo}${r.email === "enviado" ? ", e-mail enviado" : ""}, aparelhos ${r.push.entregues}/${r.push.aparelhos}`);
      } catch (e) { res.erros.push(String(e?.message || e).slice(0, 200)); }
    });
    res.erros = res.erros.slice(0, 20);
    return res;
  }

  async function rotinaDiaria(db) {
    const k = await chaves(db), dia = hoje(), res = { dia, usuarios: 0, avisados: 0, emails: 0, notificacoes: 0, erros: [] };
    await todos(db, async (user) => {
      res.usuarios++;
      try {
        // Um aviso por pessoa por manhã, mesmo que a rotina rode duas vezes.
        const { data: ja } = await db.from("avisos_enviados").select("canais").eq("user_id", user.id).eq("dia", dia).maybeSingle();
        if (/(^|; )email: /.test(ja?.canais || "")) return;
        const r = await avisaUsuario(db, user, k);
        if (!r) return;
        res.avisados++; if (r.email === "enviado") res.emails++; res.notificacoes += r.push.entregues;
        if (/^erro/.test(r.email)) res.erros.push(`e-mail: ${r.email}`);
        await anota(db, user.id, dia, `${r.limite ? `limite: ${r.limite}; ` : ""}${r.meta ? `meta: ${r.meta}; ` : ""}email: ${r.email}; push: ${r.push.entregues}/${r.push.aparelhos}`, true);
      } catch (e) { res.erros.push(String(e?.message || e).slice(0, 200)); }
    });
    res.erros = res.erros.slice(0, 20);
    return res;
  }

  const ultimoTeste = new Map();
  return async function handler(req) {
    try {
      if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });
      if (req.method === "GET" && new URL(req.url).searchParams.has("autoteste")) return json(await autoteste());
      const db = admin();
      if (req.method === "GET") return json({ chavePublica: (await chaves(db)).publica });
      if (req.method !== "POST") return json({ erro: "Método não aceito." }, 405);
      const segredo = req.headers.get("x-avisos-segredo");
      if (segredo) {
        const { data: confere } = await db.rpc("avisos_confere_segredo", { s: segredo });
        if (confere !== true) return json({ erro: "Segredo inválido." }, 401);
        const pedido = await req.json().catch(() => ({}));
        return json(pedido?.rotina === "noite" ? await rotinaDaNoite(db) : await rotinaDiaria(db));
      }
      const token = (req.headers.get("authorization") || "").replace(/^Bearer\s+/i, "");
      const { data: quem } = token ? await db.auth.getUser(token) : { data: null };
      if (!quem?.user) return json({ erro: "Entre no app para pedir um aviso de teste." }, 401);
      const corpo = await req.json().catch(() => ({}));
      if (corpo.teste !== true && corpo.teste !== "semana" && corpo.teste !== "noite") return json({ erro: "Pedido não reconhecido." }, 400);
      // Um teste por minuto por pessoa, para ninguém gastar a cota de e-mails apertando o botão sem parar.
      const ultimo = ultimoTeste.get(quem.user.id) || 0, t = agora().getTime();
      if (t - ultimo < 60000) return json({ erro: "Espere um minuto para pedir outro teste." }, 429);
      ultimoTeste.set(quem.user.id, t);
      if (corpo.teste !== true) return json(await noiteDoUsuario(db, quem.user, await chaves(db), hoje(), corpo.teste));
      return json(await avisaUsuario(db, quem.user, await chaves(db), { teste: true }));
    } catch (e) {
      console.error(e);
      return json({ erro: String(e?.message || e) }, 500);
    }
  };
}
